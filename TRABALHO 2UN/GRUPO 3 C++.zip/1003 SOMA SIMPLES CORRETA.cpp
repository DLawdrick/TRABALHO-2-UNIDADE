#include <iostream>
using namespace std;

int main() {
    int a, b, SOMA;
    cin >> a >> b;
    SOMA = a + b;
    cout << "SOMA = " << SOMA << endl;
    return 0;
}

